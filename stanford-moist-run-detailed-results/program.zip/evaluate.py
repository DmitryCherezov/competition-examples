#!/usr/bin/env python
"""
    get a pair of files from the res and ref directories
    and pass them to Regristration metrics. write result to the out directory
"""
import os, sys, optparse, re
import subprocess
import inspect
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

"""
def findTruth(submitted_file, truth_dir):
    ''' given a submitted file find the corresponding truth file'''
    m = re.search(r"(\d+)\.mha$", submitted_file)
    if m is not None:
        number_string = m.groups(0)[0]
        dirList=os.listdir(truth_dir)
        for truth_file in dirList:
            if truth_file.rfind(number_string+'.mha') < 0:
                continue
            else:
                return truth_file
    return None
"""
def findTruth(submitted_file, truth_dir):
    ''' given a submitted file find the corresponding truth file'''
    m = re.search(r"^([a-zA-Z0-9]+)_", submitted_file)
    if m is not None:
        base_name = m.groups(0)[0]
        dirList=os.listdir(truth_dir)
        for truth_file in dirList:
            if base_name in truth_file:
                return truth_file
    return None
            

#only needed to append the label to the file name
def compressedLabel(labels):
    '''remove white space from label string'''
    label_list = labels.split()
    return ''.join(label_list)   


def prepareScores(log_file, scores_file):      
    #input_file=sys.argv[1]
    #output_file=sys.argv[2]

    #metrics is a dictionary which keys holding metrics discription and values are lists holding the actual metric values that we want to average 
    metrics = {}

    with open(log_file) as f:
        for line in f:
            if re.match('^[A-Z]{3,}\s*=',line):#match three capital letters, several spaces and equal sign to match something like DICE  =
                loo = line.split()
                key = loo[0]
                val = float(loo[2])

                #metrics[key].append(val)

                if key in metrics:
                    metrics[key].append(val)
                else:
                    #if key is not present initialize
                    metrics[key] = []
                    metrics[key].append(val)

    #print metrics

    out = open(scores_file, "w")
    for key in metrics.keys():
        val = sum(metrics[key])/len(metrics[key])
        #print val, len(metrics[key])
        out.write(key+": "+str(val)+"\n")

    out.close()

def createHTML(log_file, out_dir):

    htmlOutputDir = os.path.join(out_dir, "html")
    if not os.path.exists(htmlOutputDir):
        os.makedirs(htmlOutputDir)

    # this is a dictionary with keys corresponding to image name and values corresponding to dictionary which
    # holds metric name and corresponding metric values
    cases={}

    with open(log_file) as f:
        for line in f:
            if re.match("^Name:", line):#match beginning of the evaluation piece
                loo = line.split()
                name = loo[1]
                cases[name]={}#make a new dictionary for each image

            elif re.match('^[A-Z]{3,}\s*=', line):#match three capital letters, several spaces and equal sign to match something like DICE  =
                loo = line.split()
                key = loo[0]
                val = float(loo[2])
                
                cases[name][key] = val
                #metrics[key].append(val)
                #elif re.match("^Execution time", line):#match the end of evaluation piece
                #cases.append(case)

    plt.figure(1, figsize=(12,6))
    plt.subplot(1,1,1)

    #fig,ax=plt.subplots()
    #fig.set_size_inches(10,6)
    #figure = plt.figure()
    for case_name in sorted(cases.keys()):
        x=[]
        y=[]
        for num,key in enumerate(cases[case_name].keys()):
            x.append(num)
            y.append(cases[case_name][key])

        plt.plot(x, y, linestyle="solid", marker="o", label=case_name)
        #ax.plot(x, y, linestyle="solid", marker="o", label=case_name)

    for case_name in cases.keys():
        tick_labels = cases[case_name].keys()
        break

    lgd = plt.legend(loc="upper left", bbox_to_anchor=(1.01, 1), prop={'size':8}, borderaxespad=0.)#prop={'size':6},
    plt.title("Evaluation metrics")
    plt.xlabel("Metric")
    plt.ylabel("Value")
    plt.xticks(x, tick_labels)
    plt.xlim(-0.1, len(x)-1+0.1)

    #ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1), prop={'size':6}, borderaxespad=0.)
    #ax.set_title("Detailed results for each image")
    #ax.set_xlabel("Metric")
    #ax.set_ylabel("Value")
    #ax.set_xticklabels(tick_labels)
    
    image_path = os.path.join(out_dir, "test-plot.png")
    plt.savefig(image_path, bbox_extra_artists=(lgd,), bbox_inches='tight', dpi=100)
    data_uri1 = open(image_path, 'rb').read().encode('base64').replace('\n', '') #encode the image as base64 to embed it in the html
    img_tag1 = 'src="data:image/png;base64,{0}"'.format(data_uri1)

    imgString = """
<p>
<img border="0" %s alt="Image" width="1200" height="600">
<p>""" % img_tag1


    """<!DOCTYPE html>
<html>
<head>
    <title>Demo Html</title>
    <link href="theme.default.css" rel="stylesheet">  #Make sure this is a public location
    <script type="text/javascript" src="jquery.min.js"></script> #Make sure this is a public location
    <script type="text/javascript" src="jquery.tablesorter.min.js"></script> #Make sure this is a public location
    <script>
       $(function(){
          $("#table1").tablesorter({widgets: ['zebra']});
       });
    </script>
    <style>
        table.tablesorter td {
            text-align: center;
        }

        td.left-align {
            text-align: left !important;
        }
    </style>  
</head>
<body>
<p>Description here</p>
<p>
The overall score and the scores in different categories of this system is given in the below table. </p>
<p>
<img border="0" %s alt="FROC" width="576pt" height="432pt">
<p>
The following table summarizes the results.</p>
<p>
</body>
</html>
    """


    tableString = "<tr>\n"
    tableString = tableString + "<th>Image Name</th>\n"
    for image_name in cases.keys():
        for metric_key in cases[image_name]:
            rowString = "<th>%s</th>\n" % metric_key
            tableString = tableString + rowString
        break#do it only once

    tableString = tableString + "</tr>\n"    

    for image_name in sorted(cases.keys()):
        tableString = tableString + "<tr>\n"
        rowString = "  <td>%s</td>\n" % image_name
        tableString = tableString + rowString
        for metric_key  in cases[image_name].keys():
            rowString = "  <td>%.3f</td>\n" % float(cases[image_name][metric_key])
            tableString = tableString + rowString
        tableString = tableString + "</tr>\n"

    #print tableString


    #htmlTableString = """<table border=1 class = "tablesorter" id="table1" style="width: auto; margin: 10px auto 0 auto;">\n""" + tableString + "</table>\n"
    htmlTableString = "<table border=1>\n" + tableString + "</table>\n"

    htmlString = """<!DOCTYPE html>
<html>
<head>
    <title>Demo HTML</title>
</head>
<body>
<p>Detailed evaluation results for each image are shown in the figure below</p>
%s
<p>Detailed evaluation results are provided in the table below</p>
%s
</body>
</html>""" % (imgString, htmlTableString)

    #print htmlString

    htmlfile = open(htmlOutputDir+"/detailed_results.html", "w")
    htmlfile.write(htmlString)
    htmlfile.close()


def main():
    ''' inputs are ;
       an input directory containing a ref and res subfolders
       an output directory
    '''
    parser = optparse.OptionParser()
    
    options, args = parser.parse_args()
    if len(args) != 2:
        parser.error("the wrong number of arguments")

    submit_dir = os.path.join(args[0], 'res') 
    truth_dir = os.path.join(args[0], 'ref')
    out_dir = args[1]
    
    #Region 1 in VS is the complete tumor (labels 1+2+3+4)
    #Region 2 is the core tumor (labels 3+4)
    #Region 3 is the enhancing tumor (label 4)
    #labels = ['1 2 3 4', '3 4', '4']
    #eval_seg_args="-use DICE,JACRD,AUC,KAPPA,RNDIND,ADJRIND,ICCORR,VOLSMTY,MUTINF,MAHLNBS,VARINFO,GCOERR,PROBDST,SNSVTY,SPCFTY,PRCISON,ACURCY,FALLOUT,HDRFDST@0.96@,FMEASR@0.5@"
    #eval_seg_args = '-use DICE'

    eval_seg_args="DICE,JACRD,AUC,KAPPA,RNDIND,ADJRIND,ICCORR,VOLSMTY,MUTINF"
    #eval_seg_args="DICE,JACRD,AUC"

    if os.path.isdir(submit_dir) and os.path.isdir(truth_dir):
        if not os.path.exists(out_dir):
            os.makedirs(out_dir)

        #artem's hack, the name of the output file changed to log.txt
        output_file_name = os.path.join(out_dir, 'evalseg.log')
        scores_file_name = os.path.join(out_dir, 'scores.txt')
        out_handle = open(output_file_name, 'a')
        
        # do exe file only once
        exe_path = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
        exe_file = os.path.join(exe_path,'EvaluateSegmentation')
        subprocess.call(['chmod','+x',exe_file])

        submit_list=os.listdir(submit_dir)
        for submitted_file in submit_list:
            #truth = submitted_file
            truth = findTruth(submitted_file, truth_dir)
            if truth is None:
                print 'no truth file found for ' + submitted_file
            else:
                submit_file = os.path.join(submit_dir, submitted_file)
                truth_file = os.path.join(truth_dir, truth)
                #convert_script = os.path.join(exe_path,'convert-scores-file.py')
                #print "exe_file: ", exe_file
                #print "submit_file: ", submit_file
                #print "truth_file: ", truth_file
                #print "type: ", type(exe_file)
                #print "type: ", type(eval_seg_args)
                #for label in labels:
                #print exe_file
                #print eval_seg_args

                #write name of the submitted file to the log so that we can find metrics for each submitted image
                out_handle.write("Name: " + submitted_file + "\n\n")
                # flush is supposed to flush print buffer so that name for each case is printed before the evaluation results, 
                # without it the output was messed up
                out_handle.flush()

                subprocess.call([exe_file, truth_file, submit_file, '-use', eval_seg_args], stdout=out_handle)
                out_handle.flush()

                #subprocess.call([convert_script, output_file_name, scores_file_name])
                #subprocess.call(['EvaluateSegmentation', truth_file, submit_file, '-all'], stdout=out_handle)
        out_handle.close()

        prepareScores(output_file_name, scores_file_name)
        createHTML(output_file_name, out_dir)

        #exe_path = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
        #scores_script = os.path.join(exe_path,'calculate-scores.py')
        #subprocess.call(['chmod', '+x', scores_script])
        #subprocess.call([scores_script, output_file_name, scores_file_name])

if __name__ == "__main__":
    main()
